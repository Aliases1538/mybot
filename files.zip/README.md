```markdown
Profile-countdown-userbot — Telegram userbot (Pyrogram)
======================================================

Qisqacha:
- Profil bio ichida belgilangan sana/vaqtgacha qolgan vaqt hisoblanadi va doimiy yangilanadi.
- .sozlash orqali shablon (template) yaratish.
- .matn yoki .templates bilan shablonlarni inline keyboard orqali tanlash va yuborish.
- .setcountdown/.clearcountdown/.setbioprefix/.deltemplate kabi yordamchi buyruqlar mavjud.

Muhim: API_ID=21279015 va API_HASH ni oldingiz. STRING_SESSION-ni yaratish uchun generate_session.py skriptidan foydalaning (uni PythonAnywhere konsolida yoki lokal mashinangizda ishga tushiring). STRING_SESSION juda maxfiy: uni hech qachon oshkor qilmang.

1) STRING_SESSION olish (generate_session.py)
---------------------------------------------
1.1 Mahalliy yoki PythonAnywhere konsolida virtualenv yarating va faollashtiring:
    python3 -m venv ~/venv_profilebot
    source ~/venv_profilebot/bin/activate

1.2 Kerakli paketlarni o'rnating:
    pip install -r requirements.txt

1.3 Env o'zgaruvchilarni vaqtincha o'rnating (bash):
    export API_ID=21279015
    export API_HASH="4c25a868bfd3be62a606bb7e0e82870b"

1.4 Sessiya yaratish:
    python generate_session.py

Skript sizni Telegram login jarayonidan o'tkazadi (telefon, kod yoki Telegram orqali tasdiqlash). Oxirida STRING_SESSION chiqariladi — uni nusxa olib saqlang.

2) PythonAnywhere-ga deploy (an'anaviy bosqichlar)
-------------------------------------------------
2.1 Fayllarni yuklash:
    - main.py, generate_session.py, requirements.txt va README.md ni PythonAnywhere fayl menejeri yordamida yuklang yoki Git orqali klon qiling.

2.2 Virtual muhit (PythonAnywhere konsolida):
    python3 -m venv ~/venv_profilebot
    source ~/venv_profilebot/bin/activate
    pip install -r /home/yourusername/path/to/requirements.txt

2.3 Muhit o'zgaruvchilarni sozlash:
    - Bash konsol (yoki Web -> Environment variables bo'limi) orqali quyidagilarni o'rnating:
      export API_ID=21279015
      export API_HASH="4c25a868bfd3be62a606bb7e0e82870b"
      export STRING_SESSION="SIZNING_GENERAT_QILGAN_STRING_SESSION"
      export UPDATE_INTERVAL=2        # agar FloodWait qilsa, bu qiymatni kattalashtiring
      export DB_PATH="/home/yourusername/data.db"
      export APP_NAME="my_profile_countdown"

    Eslatma: PythonAnywhere web UI-da "Always-on task" uchun Environment variables joyi mavjud — u yerga qo'shish tavsiya qilinadi.

2.4 STRING_SESSION ni olish uchun:
    - Agar siz STRING_SESSION-ni lokal mashinada oldingiz — uni PythonAnywhere-ga env sifatida qo'shing.
    - Agar PythonAnywhere konsolida olmoqchi bo'lsangiz, yuqoridagi 1) bo'limni PythonAnywhere konsolida bajaring: avval API envlarni eksport qiling, keyin python generate_session.py va kod kiritib session oling.

2.5 Userbotni Always-on task (recommended):
    - PythonAnywhere -> Tasks -> Always-on tasks -> Add a new task:
      /home/yourusername/venv_profilebot/bin/python /home/yourusername/path/to/main.py
    - Agar Always-on yo'q bo'lsa, bash konsolda virtualenv faollashtirib:
      source ~/venv_profilebot/bin/activate
      python /home/yourusername/path/to/main.py
      (Lekin konsolni yopmang — tavsiya etilgan usul Always-on)

3) Foydalanish:
---------------
- .sozlash — yangi shablon yaratish (interaktiv: birinchi .sozlash, keyin .salom qatorini yuboring, so'ng shablon matnini yuboring).
- .matn yoki .templates — saqlangan shablonlar inline keyboard bilan ko‘rinadi. Tugmani bosib shablonni tanlab yuborishingiz mumkin.
- .setcountdown 2025-12-19 00:00 — profil bio countdownni o'rnatadi.
- .clearcountdown — o'chiradi.
- .setbioprefix TEXT — profil bio boshiga qo'shimcha matn qo'yadi (emoji kabi).
- .deltemplate .salom — shablonni o'chiradi.
- Agar chatga butunlay shablon triggerini (.salom) yuborsangiz, userbot u xabarni o'chirib o'rniga shablon matnini yuboradi.

4) FloodWait va tavsiyalar:
--------------------------
- Profil bio-ni har soniyada yangilash Telegram cheklovlariga olib kelishi mumkin. Agar FloodWait xatosi ko'p bo'lsa, UPDATE_INTERVAL ni 2-5 soniyaga oshiring.
- STRING_SESSION, API_HASH va API_ID maxfiy ma'lumot — ularni ishonchli joyda saqlang.

5) Keyingi qo'shimchalar (hohlasangiz men qo'shaman):
----------------------------------------------------
- Shablon ichida {date}, {time_left}, {user} kabi o'zgaruvchilar qo'llab-quvvatlash.
- Inline keyboard orqali shablonlarni tartiblash, qidirish va sahifalash.
- Veb-panel (minimal) shablonlar boshqaruvi uchun.

Agar siz xohlasangiz, hozir men siz bilan STRING_SESSION chiqarilishiga yordam bera olaman (siz telefon/kodni kiritsangiz) — lekin men server tomonida sessiyani yaratolmayman; buning uchun siz generate_session.py skriptini ishga tushirishingiz kerak. Agar xohlasangiz, men PythonAnywhere-da ENV sozlash va Always-on task sozlash uchun aniq buyruqlarni yozib beraman (sizning PythonAnywhere username kerak bo'ladi).
```